package com.kream.root.main.CSVParser;

public interface Parser<T> {
    T parse(String str);
}
